# Aula 22 — Ponteiros em Linguagem C

Soluções das cinco questões da seção **9. Exercícios práticos** do PDF *Aula 22 - Ponteiro*.

1. **Endereço de memória:** lê um inteiro e mostra o valor e seu endereço com `%p` e `(void *)`.
2. **Utilizando ponteiros:** declara o valor inicial 20, guarda seu endereço e acessa o valor com `*ponteiro`.
3. **Alteração de valores:** modifica o valor inicial 15 para 50 por meio do ponteiro.
4. **Ponteiros e funções:** a função `dobrar(int *numero)` altera o número informado pelo usuário.
5. **Ponteiros e vetores:** lê cinco inteiros e mostra os elementos usando aritmética de ponteiros.

Cada arquivo `.c` é independente. Para compilar, por exemplo:

```bash
gcc -std=c11 -Wall -Wextra -pedantic questao-04-ponteiros-funcoes.c -o questao4
./questao4
```

**Observação:** endereços de memória variam entre execuções. Os testes verificam o valor exibido e a presença do endereço, sem exigir um endereço específico.
