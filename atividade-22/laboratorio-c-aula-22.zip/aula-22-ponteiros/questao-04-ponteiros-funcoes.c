#include <stdio.h>
#include <limits.h>

/* A funcao recebe o endereco e altera a variavel original. */
void dobrar(int *numero) {
    *numero *= 2;
}

int main(void) {
    int numero;

    printf("Digite um numero inteiro: ");
    if (scanf("%d", &numero) != 1) {
        puts("Entrada invalida. Digite um numero inteiro.");
        return 1;
    }

    /* Impede overflow na multiplicacao por dois. */
    if (numero > INT_MAX / 2 || numero < INT_MIN / 2) {
        puts("Numero fora do intervalo permitido para dobrar.");
        return 1;
    }

    dobrar(&numero);
    printf("Resultado: %d\n", numero);

    return 0;
}
