#include <stdio.h>

#define TAMANHO 5

int main(void) {
    int numeros[TAMANHO];
    int *ponteiro = numeros;

    for (int i = 0; i < TAMANHO; i++) {
        printf("Digite o %do numero inteiro: ", i + 1);

        if (scanf("%d", &numeros[i]) != 1) {
            puts("Entrada invalida. Digite um numero inteiro.");
            return 1;
        }
    }

    puts("\nElementos do vetor:");
    for (int i = 0; i < TAMANHO; i++) {
        printf("%d\n", *(ponteiro + i));
    }

    return 0;
}
