#include <stdio.h>

int main(void) {
    int numero;

    printf("Digite um numero inteiro: ");
    if (scanf("%d", &numero) != 1) {
        puts("Entrada invalida. Digite um numero inteiro.");
        return 1;
    }

    printf("Valor informado: %d\n", numero);
    printf("Endereco de memoria: %p\n", (void *)&numero);

    return 0;
}
