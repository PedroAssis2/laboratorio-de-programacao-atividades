#include <stdio.h>
#include <limits.h>
#include "calculos.h"

int main(void) {
    int numero;
    printf("Digite um numero: ");
    if (scanf("%d", &numero) != 1 || numero > INT_MAX / 2 || numero < INT_MIN / 2) {
        puts("Numero invalido ou fora do limite para calcular o dobro.");
        return 1;
    }
    printf("Dobro: %d\n", dobro(numero));
    return 0;
}
