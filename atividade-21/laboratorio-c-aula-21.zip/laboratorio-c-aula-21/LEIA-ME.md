# Aula 21 — Bibliotecas e manipulação de arquivos

Este pacote acompanha os dois PDFs da Aula 21.

- `Aula21_Bibliotecas/`: exemplo de biblioteca própria com `calculos.h`, `calculos.c` e `main.c`.
- `Aula21_Arquivos/`: questões 1, 2 e 3 do PDF de manipulação de arquivos.

## Compilar

```bash
gcc -std=c11 -Wall -Wextra -pedantic Aula21_Bibliotecas/main.c Aula21_Bibliotecas/calculos.c -o biblioteca
gcc -std=c11 -Wall -Wextra -pedantic Aula21_Arquivos/questao-01-cadastro.c -o questao1
gcc -std=c11 -Wall -Wextra -pedantic Aula21_Arquivos/questao-02-numeros.c -o questao2
gcc -std=c11 -Wall -Wextra -pedantic Aula21_Arquivos/questao-03-funcionarios-struct.c -o questao3
```

**Atenção:** as questões 1 e 3 usam o nome `funcionarios.txt`, mas com formatos diferentes. Execute-as em diretórios de trabalho separados para não misturar registros. A questão 1 sobrescreve o arquivo; a questão 3 acrescenta novos registros.
