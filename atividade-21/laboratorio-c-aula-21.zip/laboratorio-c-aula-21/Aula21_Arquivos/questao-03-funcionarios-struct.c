#include <stdio.h>

#define MAX_FUNCIONARIOS 5
#define NOME_ARQUIVO "funcionarios.txt"

typedef struct {
    char nome[50];
    float salario;
    int horasExtras;
} Funcionario;

int cadastrar(Funcionario *funcionario) {
    printf("Nome: ");
    if (scanf(" %49[^\n]", funcionario->nome) != 1) return 0;

    printf("Salario: ");
    if (scanf("%f", &funcionario->salario) != 1 ||
        funcionario->salario < 0) return 0;

    printf("Horas extras: ");
    if (scanf("%d", &funcionario->horasExtras) != 1 ||
        funcionario->horasExtras < 0) return 0;

    return 1;
}

int salvar(FILE *arquivo, const Funcionario *funcionario) {
    return fprintf(arquivo, "%s;%.2f;%d\n",
                   funcionario->nome,
                   funcionario->salario,
                   funcionario->horasExtras) > 0;
}

int listar(void) {
    FILE *arquivo = fopen(NOME_ARQUIVO, "r");
    Funcionario funcionario;
    int total = 0;

    if (arquivo == NULL) {
        puts("Nenhum registro encontrado.");
        return 0;
    }

    puts("\n--- FUNCIONARIOS CADASTRADOS ---");

    while (fscanf(arquivo, " %49[^;];%f;%d",
                  funcionario.nome,
                  &funcionario.salario,
                  &funcionario.horasExtras) == 3) {
        printf("\nNome: %s\nSalario: R$ %.2f\nHoras extras: %d\n",
               funcionario.nome,
               funcionario.salario,
               funcionario.horasExtras);
        total++;
    }

    if (ferror(arquivo)) {
        perror("Erro ao ler o arquivo");
        fclose(arquivo);
        return -1;
    }

    fclose(arquivo);
    printf("\nTotal de registros apresentados: %d\n", total);
    return total;
}

int main(void) {
    int quantidade;
    Funcionario funcionario;

    printf("Quantos funcionarios deseja adicionar (1 a 5)? ");
    if (scanf("%d", &quantidade) != 1 ||
        quantidade < 1 || quantidade > MAX_FUNCIONARIOS) {
        puts("Quantidade invalida.");
        return 1;
    }

    FILE *arquivo = fopen(NOME_ARQUIVO, "a");
    if (arquivo == NULL) {
        perror("Erro ao abrir funcionarios.txt");
        return 1;
    }

    for (int i = 0; i < quantidade; i++) {
        printf("\nFuncionario %d\n", i + 1);
        if (!cadastrar(&funcionario) || !salvar(arquivo, &funcionario)) {
            puts("Erro ao cadastrar ou gravar os dados.");
            fclose(arquivo);
            return 1;
        }
    }

    if (fclose(arquivo) != 0) {
        perror("Erro ao finalizar gravacao");
        return 1;
    }

    puts("\nDados adicionados com sucesso.");
    return listar() < 0 ? 1 : 0;
}
