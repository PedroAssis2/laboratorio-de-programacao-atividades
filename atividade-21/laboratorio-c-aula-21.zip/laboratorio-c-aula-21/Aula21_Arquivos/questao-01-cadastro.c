#include <stdio.h>

#define MAX_FUNCIONARIOS 5
#define NOME_ARQUIVO "funcionarios.txt"

typedef struct {
    char nome[50];
    int matricula;
} Funcionario;

int main(void) {
    Funcionario funcionario;
    int quantidade;

    printf("Quantos funcionarios deseja cadastrar (1 a 5)? ");
    if (scanf("%d", &quantidade) != 1 ||
        quantidade < 1 || quantidade > MAX_FUNCIONARIOS) {
        puts("Quantidade invalida.");
        return 1;
    }

    FILE *arquivo = fopen(NOME_ARQUIVO, "w");
    if (arquivo == NULL) {
        perror("Nao foi possivel criar funcionarios.txt");
        return 1;
    }

    for (int i = 0; i < quantidade; i++) {
        printf("\nFuncionario %d\n", i + 1);
        printf("Nome: ");
        if (scanf(" %49[^\n]", funcionario.nome) != 1) {
            puts("Nome invalido.");
            fclose(arquivo);
            return 1;
        }

        printf("Matricula: ");
        if (scanf("%d", &funcionario.matricula) != 1 ||
            funcionario.matricula < 0) {
            puts("Matricula invalida.");
            fclose(arquivo);
            return 1;
        }

        if (fprintf(arquivo, "Nome: %s\nMatricula: %d\n\n",
                    funcionario.nome, funcionario.matricula) < 0) {
            perror("Erro ao gravar funcionario");
            fclose(arquivo);
            return 1;
        }
    }

    if (fclose(arquivo) != 0) {
        perror("Erro ao finalizar gravacao");
        return 1;
    }

    printf("\n%d funcionario(s) gravado(s) com sucesso em %s.\n",
           quantidade, NOME_ARQUIVO);
    return 0;
}
