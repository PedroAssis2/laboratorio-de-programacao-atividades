#include <stdio.h>

#define TOTAL_NUMEROS 5
#define NOME_ARQUIVO "numeros.txt"

int main(void) {
    int numero;
    FILE *arquivo = fopen(NOME_ARQUIVO, "w");

    if (arquivo == NULL) {
        perror("Erro ao criar numeros.txt");
        return 1;
    }

    for (int i = 0; i < TOTAL_NUMEROS; i++) {
        printf("Digite o %do numero inteiro: ", i + 1);

        if (scanf("%d", &numero) != 1) {
            puts("Entrada invalida.");
            fclose(arquivo);
            return 1;
        }

        if (fprintf(arquivo, "%d\n", numero) < 0) {
            perror("Erro ao gravar numero");
            fclose(arquivo);
            return 1;
        }
    }

    if (fclose(arquivo) != 0) {
        perror("Erro ao fechar arquivo de escrita");
        return 1;
    }

    arquivo = fopen(NOME_ARQUIVO, "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir numeros.txt para leitura");
        return 1;
    }

    puts("\nNumeros armazenados no arquivo:");
    while (fscanf(arquivo, "%d", &numero) == 1) {
        printf("%d\n", numero);
    }

    if (ferror(arquivo)) {
        perror("Erro ao ler numeros.txt");
        fclose(arquivo);
        return 1;
    }

    if (fclose(arquivo) != 0) {
        perror("Erro ao fechar arquivo de leitura");
        return 1;
    }

    return 0;
}
