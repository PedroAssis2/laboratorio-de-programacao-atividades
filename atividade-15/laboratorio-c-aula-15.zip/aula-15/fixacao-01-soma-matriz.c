#include <stdio.h>

#define LINHAS 2
#define COLUNAS 3

int main(void) {
    int matriz[LINHAS][COLUNAS];
    int soma = 0;

    for (int linha = 0; linha < LINHAS; linha++) {
        for (int coluna = 0; coluna < COLUNAS; coluna++) {
            printf("Valor [%d][%d]: ", linha, coluna);

            if (scanf("%d", &matriz[linha][coluna]) != 1) {
                puts("Erro: informe um numero inteiro.");
                return 1;
            }

            soma += matriz[linha][coluna];
        }
    }

    printf("Soma dos elementos: %d\n", soma);
    return 0;
}
