#include <stdio.h>

#define TAMANHO 3

int main(void) {
    int matriz[TAMANHO][TAMANHO];
    int pares = 0;

    for (int linha = 0; linha < TAMANHO; linha++) {
        for (int coluna = 0; coluna < TAMANHO; coluna++) {
            printf("Valor [%d][%d]: ", linha, coluna);

            if (scanf("%d", &matriz[linha][coluna]) != 1) {
                puts("Erro: informe um numero inteiro.");
                return 1;
            }

            if (matriz[linha][coluna] % 2 == 0) {
                pares++;
            }
        }
    }

    printf("Quantidade de valores pares: %d\n", pares);
    return 0;
}
