#include <stdio.h>

#define TAMANHO 3

int main(void) {
    int matriz[TAMANHO][TAMANHO];
    int maior = 0;

    for (int linha = 0; linha < TAMANHO; linha++) {
        for (int coluna = 0; coluna < TAMANHO; coluna++) {
            printf("Valor [%d][%d]: ", linha, coluna);

            if (scanf("%d", &matriz[linha][coluna]) != 1) {
                puts("Erro: informe um numero inteiro.");
                return 1;
            }

            if (linha == 0 && coluna == 0) {
                maior = matriz[linha][coluna];
            } else if (matriz[linha][coluna] > maior) {
                maior = matriz[linha][coluna];
            }
        }
    }

    printf("Maior valor: %d\n", maior);
    return 0;
}
