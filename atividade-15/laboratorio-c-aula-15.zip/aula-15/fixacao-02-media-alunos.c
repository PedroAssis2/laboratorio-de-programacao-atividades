#include <stdio.h>

#define ALUNOS 3
#define PROVAS 2

int main(void) {
    float notas[ALUNOS][PROVAS];

    for (int aluno = 0; aluno < ALUNOS; aluno++) {
        for (int prova = 0; prova < PROVAS; prova++) {
            printf("Nota do aluno %d na prova %d: ", aluno + 1, prova + 1);

            if (scanf("%f", &notas[aluno][prova]) != 1 ||
                notas[aluno][prova] < 0.0f ||
                notas[aluno][prova] > 10.0f) {
                puts("Erro: a nota deve estar entre 0 e 10.");
                return 1;
            }
        }
    }

    for (int aluno = 0; aluno < ALUNOS; aluno++) {
        float soma = 0.0f;

        for (int prova = 0; prova < PROVAS; prova++) {
            soma += notas[aluno][prova];
        }

        printf("Media do aluno %d: %.2f\n", aluno + 1, soma / PROVAS);
    }

    return 0;
}
