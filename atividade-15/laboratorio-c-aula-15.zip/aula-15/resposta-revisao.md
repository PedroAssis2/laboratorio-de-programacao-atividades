## Questão de revisão

A saída é **20**, porque 2 + 4 + 6 + 8 = 20.
