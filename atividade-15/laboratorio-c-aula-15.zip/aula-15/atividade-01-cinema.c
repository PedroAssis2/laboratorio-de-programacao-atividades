#include <stdio.h>

#define FILEIRAS 3
#define ASSENTOS 4

int main(void) {
    int ocupacao[FILEIRAS][ASSENTOS] = {
        {1, 0, 0, 1},
        {0, 1, 0, 0},
        {1, 1, 0, 0}
    };
    int ocupados = 0;
    int disponiveis = 0;

    puts("Mapa de assentos (0 = disponivel; 1 = ocupado):");

    for (int linha = 0; linha < FILEIRAS; linha++) {
        for (int coluna = 0; coluna < ASSENTOS; coluna++) {
            printf("%d ", ocupacao[linha][coluna]);

            if (ocupacao[linha][coluna] == 1) {
                ocupados++;
            } else {
                disponiveis++;
            }
        }
        putchar('\n');
    }

    printf("Assentos ocupados: %d\n", ocupados);
    printf("Assentos disponiveis: %d\n", disponiveis);

    return 0;
}
