#include <stdio.h>

int main(void) {
    int matriz[2][2];

    for (int linha = 0; linha < 2; linha++) {
        for (int coluna = 0; coluna < 2; coluna++) {
            printf("Digite o valor da linha %d, coluna %d: ", linha + 1, coluna + 1);
            if (scanf("%d", &matriz[linha][coluna]) != 1) {
                printf("Erro: informe um numero inteiro valido.\n");
                return 1;
            }
        }
    }

    printf("\nMatriz informada:\n");
    for (int linha = 0; linha < 2; linha++) {
        for (int coluna = 0; coluna < 2; coluna++) {
            printf("%4d", matriz[linha][coluna]);
        }
        printf("\n");
    }

    return 0;
}
