#include <stdio.h>

int main(void) {
    int matriz[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };
    int soma = 0;

    printf("Matriz 3x3:\n");
    for (int linha = 0; linha < 3; linha++) {
        for (int coluna = 0; coluna < 3; coluna++) {
            printf("%4d", matriz[linha][coluna]);
            soma += matriz[linha][coluna];
        }
        printf("\n");
    }

    printf("Soma dos elementos: %d\n", soma);
    return 0;
}
