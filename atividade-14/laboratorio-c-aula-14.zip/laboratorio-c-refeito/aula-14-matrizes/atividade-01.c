#include <stdio.h>

int main(void) {
    int matriz[2][2] = {
        {10, 20},
        {30, 40}
    };

    printf("Matriz 2x2:\n");
    for (int linha = 0; linha < 2; linha++) {
        for (int coluna = 0; coluna < 2; coluna++) {
            printf("%4d", matriz[linha][coluna]);
        }
        printf("\n");
    }

    return 0;
}
