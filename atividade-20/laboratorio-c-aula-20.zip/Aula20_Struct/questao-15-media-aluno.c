#include <stdio.h>

typedef struct {
    char nome[50];
    float nota1;
    float nota2;
} Aluno;

int main(void) {
    Aluno aluno;
    float media;

    printf("Nome do aluno: ");
    if (scanf(" %49[^\n]", aluno.nome) != 1) return 1;

    printf("Primeira nota: ");
    if (scanf("%f", &aluno.nota1) != 1 ||
        aluno.nota1 < 0 || aluno.nota1 > 10) {
        puts("Nota invalida.");
        return 1;
    }

    printf("Segunda nota: ");
    if (scanf("%f", &aluno.nota2) != 1 ||
        aluno.nota2 < 0 || aluno.nota2 > 10) {
        puts("Nota invalida.");
        return 1;
    }

    media = (aluno.nota1 + aluno.nota2) / 2.0f;

    printf("\nAluno: %s\n", aluno.nome);
    printf("Media: %.2f\n", media);
    printf("Situacao: %s\n", media >= 7.0f ? "Aprovado" : "Reprovado");
    return 0;
}
