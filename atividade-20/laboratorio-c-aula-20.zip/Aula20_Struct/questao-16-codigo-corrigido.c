#include <stdio.h>

/* O enunciado omitia o ponto e virgula apos a definicao do typedef. */
typedef struct {
    char nome[50];
    int idade;
} Pessoa;

int main(void) {
    Pessoa pessoa1 = {"Pedro", 20};
    printf("Nome: %s\n", pessoa1.nome);
    printf("Idade: %d\n", pessoa1.idade);
    return 0;
}
