#include <stdio.h>

typedef struct {
    char nome[50];
    int idade;
    float salario;
} Funcionario;

int cadastrarFuncionario(Funcionario *funcionario, int numero) {
    printf("\n--- FUNCIONARIO %d ---\n", numero);

    printf("Nome: ");
    if (scanf(" %49[^\n]", funcionario->nome) != 1) {
        puts("Nome invalido.");
        return 0;
    }

    printf("Idade: ");
    if (scanf("%d", &funcionario->idade) != 1 ||
        funcionario->idade < 0) {
        puts("Idade invalida.");
        return 0;
    }

    printf("Salario: ");
    if (scanf("%f", &funcionario->salario) != 1 ||
        funcionario->salario < 0) {
        puts("Salario invalido.");
        return 0;
    }

    return 1;
}

void apresentarFuncionario(const Funcionario *funcionario) {
    printf("Nome: %s\n", funcionario->nome);
    printf("Idade: %d\n", funcionario->idade);
    printf("Salario: R$ %.2f\n", funcionario->salario);
}

int main(void) {
    Funcionario funcionario1;
    Funcionario funcionario2;
    double diferenca;

    if (!cadastrarFuncionario(&funcionario1, 1) ||
        !cadastrarFuncionario(&funcionario2, 2)) {
        return 1;
    }

    puts("\n--- DADOS CADASTRADOS ---");
    puts("\nFuncionario 1:");
    apresentarFuncionario(&funcionario1);
    puts("\nFuncionario 2:");
    apresentarFuncionario(&funcionario2);

    if (funcionario1.salario == funcionario2.salario) {
        puts("\nOs dois funcionarios recebem o mesmo salario.");
        diferenca = 0;
    } else if (funcionario1.salario > funcionario2.salario) {
        printf("\nMaior salario: %s\n", funcionario1.nome);
        diferenca = (double)funcionario1.salario - funcionario2.salario;
    } else {
        printf("\nMaior salario: %s\n", funcionario2.nome);
        diferenca = (double)funcionario2.salario - funcionario1.salario;
    }

    printf("Diferenca salarial: R$ %.2f\n", diferenca);
    return 0;
}
