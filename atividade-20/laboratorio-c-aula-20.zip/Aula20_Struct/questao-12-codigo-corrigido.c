#include <stdio.h>

typedef struct {
    char nome[50];
    int idade;
    float nota;
} Aluno;

int main(void) {
    Aluno aluno1 = {"Maria", 20, 8.5f};

    printf("%s\n", aluno1.nome);
    printf("%d\n", aluno1.idade);
    printf("%.1f\n", aluno1.nota);

    return 0;
}
