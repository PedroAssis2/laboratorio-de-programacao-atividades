#include <stdio.h>

typedef struct {
    char modelo[50];
    int ano;
    float valor;
} Veiculo;

int main(void) {
    Veiculo veiculo;

    printf("Modelo: ");
    if (scanf(" %49[^\n]", veiculo.modelo) != 1) return 1;

    printf("Ano: ");
    if (scanf("%d", &veiculo.ano) != 1 || veiculo.ano < 1886) {
        puts("Ano invalido.");
        return 1;
    }

    printf("Valor: ");
    if (scanf("%f", &veiculo.valor) != 1 || veiculo.valor < 0) {
        puts("Valor invalido.");
        return 1;
    }

    puts("\n--- VEICULO ---");
    printf("Modelo: %s\n", veiculo.modelo);
    printf("Ano: %d\n", veiculo.ano);
    printf("Valor: R$ %.2f\n", veiculo.valor);
    return 0;
}
