#include <stdio.h>

typedef struct {
    char nome[50];
    int idade;
    float salario;
} Funcionario;

int main(void) {
    Funcionario funcionario;

    printf("Nome do funcionario: ");
    if (scanf(" %49[^\n]", funcionario.nome) != 1) return 1;

    printf("Idade: ");
    if (scanf("%d", &funcionario.idade) != 1 || funcionario.idade < 0) {
        puts("Idade invalida.");
        return 1;
    }

    printf("Salario: ");
    if (scanf("%f", &funcionario.salario) != 1 || funcionario.salario < 0) {
        puts("Salario invalido.");
        return 1;
    }

    puts("\n--- FUNCIONARIO CADASTRADO ---");
    printf("Nome: %s\n", funcionario.nome);
    printf("Idade: %d\n", funcionario.idade);
    printf("Salario: R$ %.2f\n", funcionario.salario);
    return 0;
}
