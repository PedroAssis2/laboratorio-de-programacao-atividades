# Exercício de revisão — Aula 20

## Questões 1 a 10

1. **b)** Agrupar informações relacionadas.
2. **a)** Ponto (`.`).
3. **a)** `Pessoa pessoa1;`.
4. **c)** Um ponto e vírgula após `Produto`.
5. **b)** `Pessoa pessoa1;`.
6. **a)** `pessoa1.idade = 25;`.
7. **a)** Vetores guardam elementos do mesmo tipo; structs podem reunir campos de tipos diferentes.
8. **b)** Cria um nome alternativo para um tipo.
9. **b)** Sim, cada variável possui seus próprios campos.
10. **a)** Sim.

## Questão 12 — análise do código original

a) `%d` foi usado para imprimir o nome, e `%f` para imprimir a idade; ambos são incompatíveis com os tipos dos campos.  
b) `%s`.  
c) `%d`.  
d) Não. O campo `nome` não foi inicializado.

O código corrigido está em `questao-12-codigo-corrigido.c`.

## Questão 13

a) `Produto`.  
b) `codigo`, `nome` e `preco`.  
c) Operador ponto (`.`).

## Questão 16

Faltava `;` depois da chave de fechamento de `typedef struct`, isto é, `} Pessoa;`.
