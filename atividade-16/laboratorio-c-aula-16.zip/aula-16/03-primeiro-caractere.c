#include <stdio.h>

#define TAMANHO 100

int main(void) {
    char palavra[TAMANHO];

    printf("Digite uma palavra: ");
    if (scanf("%99s", palavra) != 1) {
        puts("Nao foi possivel ler a palavra.");
        return 1;
    }

    printf("Primeiro caractere: %c\n", palavra[0]);
    return 0;
}
