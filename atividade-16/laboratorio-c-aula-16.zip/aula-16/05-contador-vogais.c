#include <stdio.h>

#define TAMANHO 100

int main(void) {
    char palavra[TAMANHO];
    int vogais = 0;

    printf("Digite uma palavra com letras minusculas: ");
    if (scanf("%99s", palavra) != 1) {
        puts("Nao foi possivel ler a palavra.");
        return 1;
    }

    for (int i = 0; palavra[i] != '\0'; i++) {
        char letra = palavra[i];
        if (letra == 'a' || letra == 'e' || letra == 'i' ||
            letra == 'o' || letra == 'u') {
            vogais++;
        }
    }

    printf("Quantidade de vogais: %d\n", vogais);
    return 0;
}
