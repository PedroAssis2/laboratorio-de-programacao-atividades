# Aula 16 — Revisão

**6. Qual é a diferença entre `char` e uma string?**  
`char` armazena um único caractere, como `'A'`. Uma string em C é uma sequência de caracteres armazenada em um vetor de `char`, como `char palavra[] = "CASA";`.

**7. Por que uma string precisa do caractere `\0`?**  
Ele marca o final da string, permitindo que as funções e os laços identifiquem onde o texto termina.

**8. Qual é a diferença entre `scanf("%s", ...)` e `fgets(...)`?**  
`scanf("%s", ...)` para ao encontrar espaços; `fgets(...)` pode ler uma linha contendo espaços e respeita o limite do vetor informado. `fgets` pode manter a quebra de linha final.
