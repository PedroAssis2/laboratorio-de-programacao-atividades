#include <stdio.h>

#define TAMANHO 100

int main(void) {
    char palavra[TAMANHO];
    int quantidade = 0;

    printf("Digite uma palavra: ");
    if (scanf("%99s", palavra) != 1) {
        puts("Nao foi possivel ler a palavra.");
        return 1;
    }

    for (int i = 0; palavra[i] != '\0'; i++) {
        quantidade++;
    }

    printf("Quantidade de caracteres: %d\n", quantidade);
    return 0;
}
