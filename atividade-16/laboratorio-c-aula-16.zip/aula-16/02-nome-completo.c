#include <stdio.h>

#define TAMANHO 100

int main(void) {
    char nome[TAMANHO];

    printf("Digite seu nome completo: ");
    if (fgets(nome, sizeof(nome), stdin) == NULL) {
        puts("Nao foi possivel ler o nome.");
        return 1;
    }

    printf("Nome informado: %s", nome);
    return 0;
}
