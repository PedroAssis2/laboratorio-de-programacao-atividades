#include <stdio.h>
#include <string.h>

#define TAM_NOME 50
#define TAM_CODIGO 10
#define TAM_MENSAGEM 100

int main(void) {
    char nome[TAM_NOME];
    char codigo[TAM_CODIGO];
    char nomeCopiado[TAM_NOME];
    char mensagem[TAM_MENSAGEM] = "Ola, ";
    const char *curso;

    printf("Primeiro nome do estudante: ");
    if (scanf("%49s", nome) != 1) {
        puts("Erro ao ler o nome.");
        return 1;
    }

    printf("Codigo do curso (CC ou SI): ");
    if (scanf("%9s", codigo) != 1) {
        puts("Erro ao ler o codigo.");
        return 1;
    }

    if (strcmp(codigo, "CC") == 0) {
        curso = "Ciencia da Computacao";
    } else if (strcmp(codigo, "SI") == 0) {
        curso = "Sistemas de Informacao";
    } else {
        puts("Codigo invalido. Use CC ou SI.");
        return 1;
    }

    strcpy(nomeCopiado, nome);
    strcat(mensagem, nomeCopiado);
    strcat(mensagem, "!");

    puts("\n--- Dados do estudante ---");
    printf("Nome: %s\n", nomeCopiado);
    printf("Caracteres do nome: %zu\n", strlen(nome));
    printf("Curso: %s\n", curso);
    puts(mensagem);
    return 0;
}
