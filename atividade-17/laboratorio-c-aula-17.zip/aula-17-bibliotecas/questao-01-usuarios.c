#include <stdio.h>
#include <string.h>

#define TAM_NOME 50
#define TAM_PERFIL 20
#define TAM_MENSAGEM 100

int main(void) {
    char nome[TAM_NOME];
    char perfil[TAM_PERFIL];
    char nomeConfirmado[TAM_NOME];
    char mensagem[TAM_MENSAGEM] = "Bem-vindo, ";
    const char *descricaoPerfil;

    printf("Primeiro nome: ");
    if (scanf("%49s", nome) != 1) {
        puts("Erro ao ler o nome.");
        return 1;
    }

    printf("Perfil de acesso (ADMIN ou COMUM): ");
    if (scanf("%19s", perfil) != 1) {
        puts("Erro ao ler o perfil.");
        return 1;
    }

    if (strcmp(perfil, "ADMIN") == 0) {
        descricaoPerfil = "Administrador";
    } else if (strcmp(perfil, "COMUM") == 0) {
        descricaoPerfil = "Usuario comum";
    } else {
        puts("Perfil invalido. Use ADMIN ou COMUM.");
        return 1;
    }

    strcpy(nomeConfirmado, nome);
    strcat(mensagem, nomeConfirmado);
    strcat(mensagem, "!");

    puts("\n--- Cadastro de usuario ---");
    printf("Nome: %s\n", nomeConfirmado);
    printf("Caracteres do nome: %zu\n", strlen(nome));
    printf("Perfil: %s (%s)\n", perfil, descricaoPerfil);
    puts(mensagem);
    return 0;
}
