#include <stdio.h>
#include <string.h>

#define TAM_NOME 60
#define TAM_CATEGORIA 20
#define TAM_DESCRICAO 100

int main(void) {
    char nome[TAM_NOME];
    char categoria[TAM_CATEGORIA];
    char nomeCopiado[TAM_NOME];
    char descricao[TAM_DESCRICAO] = "Produto: ";
    const char *tipo;

    printf("Nome do produto: ");
    if (fgets(nome, sizeof(nome), stdin) == NULL) {
        puts("Erro ao ler o produto.");
        return 1;
    }
    nome[strcspn(nome, "\n")] = '\0';
    if (strlen(nome) == 0) {
        puts("O nome nao pode ficar vazio.");
        return 1;
    }

    printf("Categoria (HARDWARE ou PERIFERICO): ");
    if (scanf("%19s", categoria) != 1) {
        puts("Erro ao ler a categoria.");
        return 1;
    }

    if (strcmp(categoria, "HARDWARE") == 0) {
        tipo = "Hardware";
    } else if (strcmp(categoria, "PERIFERICO") == 0) {
        tipo = "Periferico";
    } else {
        puts("Categoria invalida. Use HARDWARE ou PERIFERICO.");
        return 1;
    }

    strcpy(nomeCopiado, nome);
    strcat(descricao, nomeCopiado);

    puts("\n--- Resumo do produto ---");
    printf("Nome: %s\n", nomeCopiado);
    printf("Quantidade de caracteres: %zu\n", strlen(nome));
    printf("Categoria: %s\n", tipo);
    printf("Descricao: %s\n", descricao);
    return 0;
}
