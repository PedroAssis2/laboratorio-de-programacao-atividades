#include <stdio.h>

int verificarPar(int numero) {
    return numero % 2 == 0 ? 1 : 0;
}

int main(void) {
    int numero;
    printf("Informe um numero inteiro: ");
    if (scanf("%d", &numero) != 1) {
        puts("Numero invalido.");
        return 1;
    }

    printf("%d e %s.\n", numero, verificarPar(numero) ? "par" : "impar");
    return 0;
}
