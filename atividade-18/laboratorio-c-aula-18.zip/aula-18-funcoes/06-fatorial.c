#include <stdio.h>

unsigned int calcularFatorial(int numero) {
    unsigned int resultado = 1;
    for (int i = 2; i <= numero; i++) {
        resultado *= (unsigned int)i;
    }
    return resultado;
}

int main(void) {
    int numero;
    printf("Informe um numero entre 0 e 12: ");
    if (scanf("%d", &numero) != 1 || numero < 0 || numero > 12) {
        puts("Numero invalido: use um inteiro de 0 a 12.");
        return 1;
    }

    printf("%d! = %u\n", numero, calcularFatorial(numero));
    return 0;
}
