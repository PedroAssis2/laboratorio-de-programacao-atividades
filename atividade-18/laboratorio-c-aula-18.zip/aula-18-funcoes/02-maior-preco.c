#include <stdio.h>

double maiorPreco(double primeiro, double segundo) {
    return primeiro > segundo ? primeiro : segundo;
}

int main(void) {
    double primeiro, segundo;

    printf("Preco do primeiro produto: ");
    if (scanf("%lf", &primeiro) != 1 || primeiro < 0) {
        puts("Preco invalido.");
        return 1;
    }

    printf("Preco do segundo produto: ");
    if (scanf("%lf", &segundo) != 1 || segundo < 0) {
        puts("Preco invalido.");
        return 1;
    }

    if (primeiro == segundo) {
        printf("Os dois produtos custam R$ %.2f.\n", primeiro);
    } else {
        printf("Maior preco: R$ %.2f\n", maiorPreco(primeiro, segundo));
    }
    return 0;
}
