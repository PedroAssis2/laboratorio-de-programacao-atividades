#include <stdio.h>

void exibirLinha(void) {
    puts("**********");
}

int main(void) {
    exibirLinha();
    puts("RELATORIO");
    exibirLinha();
    return 0;
}
