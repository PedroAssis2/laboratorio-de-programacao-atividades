#include <stdio.h>

void exibirMenu(void) {
    puts("\n=== CALCULADORA ===");
    puts("1 - Somar");
    puts("2 - Subtrair");
    puts("3 - Multiplicar");
    puts("4 - Dividir");
    puts("0 - Sair");
    printf("Opcao: ");
}

double somar(double a, double b) { return a + b; }
double subtrair(double a, double b) { return a - b; }
double multiplicar(double a, double b) { return a * b; }
double dividir(double a, double b) { return a / b; }

int main(void) {
    int opcao;
    double a, b, resultado;

    do {
        exibirMenu();
        if (scanf("%d", &opcao) != 1) {
            puts("Opcao invalida.");
            return 1;
        }

        if (opcao == 0) {
            puts("Calculadora encerrada.");
            break;
        }
        if (opcao < 1 || opcao > 4) {
            puts("Escolha uma opcao entre 0 e 4.");
            continue;
        }

        printf("Primeiro numero: ");
        if (scanf("%lf", &a) != 1) return 1;
        printf("Segundo numero: ");
        if (scanf("%lf", &b) != 1) return 1;

        if (opcao == 4 && b == 0.0) {
            puts("Erro: divisao por zero nao permitida.");
            continue;
        }

        switch (opcao) {
            case 1: resultado = somar(a, b); break;
            case 2: resultado = subtrair(a, b); break;
            case 3: resultado = multiplicar(a, b); break;
            case 4: resultado = dividir(a, b); break;
            default: continue;
        }
        printf("Resultado: %.2f\n", resultado);
    } while (opcao != 0);

    return 0;
}
