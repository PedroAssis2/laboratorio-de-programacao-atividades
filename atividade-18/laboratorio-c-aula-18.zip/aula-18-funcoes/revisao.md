# Revisão — Aula 18

1. `exibirLinha()` não recebe parâmetros nem retorna valor (`void`).
2. `somar()`, `subtrair()`, `multiplicar()`, `dividir()` e `maiorPreco()` recebem dois parâmetros.
3. `return` devolve à função chamadora o resultado calculado.
4. `switch` seleciona a operação conforme a opção do usuário.
5. `do...while` repete o menu e as operações até o usuário escolher sair; executa o bloco pelo menos uma vez.
6. A divisão por zero não tem resultado matemático definido; é necessário impedi-la.
