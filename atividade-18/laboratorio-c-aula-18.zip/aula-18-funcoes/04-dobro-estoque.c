#include <stdio.h>
#include <limits.h>

int dobro(int quantidade) {
    return quantidade * 2;
}

int main(void) {
    int quantidade;
    printf("Quantidade inicial em estoque: ");
    if (scanf("%d", &quantidade) != 1 ||
        quantidade < 0 || quantidade > INT_MAX / 2) {
        puts("Quantidade invalida ou muito grande.");
        return 1;
    }

    printf("Quantidade inicial: %d\n", quantidade);
    printf("Quantidade apos duplicar: %d\n", dobro(quantidade));
    return 0;
}
